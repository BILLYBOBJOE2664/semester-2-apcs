
public interface P2_Peng_Kevin_MSModelListener {
	public void cellChanged(int row, int col);
	public void modelChanged();
}
